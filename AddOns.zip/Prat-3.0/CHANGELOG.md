# Prat 3.0

## [3.7.50](https://github.com/sylvanaar/prat-3-0/tree/3.7.50) (2020-01-26)
[Full Changelog](https://github.com/sylvanaar/prat-3-0/compare/3.7.49...3.7.50)

- Add a guard against misbehaved addons which add chat types without a valid CHAT\_TYPE\_INFO entry  
