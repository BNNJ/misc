# Quartz

## [3.5-classic-5](https://github.com/Nevcairiel/Quartz/tree/3.5-classic-5) (2019-10-29)
[Full Changelog](https://github.com/Nevcairiel/Quartz/compare/3.5-classic-4...3.5-classic-5)

- Fix loading LibClassicDurations  
